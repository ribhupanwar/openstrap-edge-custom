# OpenStrap Edge Custom Build

This branch contains the custom Home UI based on the user's supplied WHOOP-style reference.

## Current UI changes

- Compact TODAY header and dark card system.
- Three primary Sleep / Recovery / Strain rings.
- Health Monitor and Stress Monitor cards on the front page.
- My Day activity rows and Add Activity / Start Activity actions.
- Smart Alarm card on the front page.
- Fitness cards reserved for VO2 Max and Biological Age calibration.
- Existing auto-detected activity review remains available.
- Existing step-source resolver/deduplication code is preserved; no blind phone+band addition was introduced.
- Existing Bluetooth/protocol/data pipeline is left intact.

## Build

The repository includes `.github/workflows/build-custom-ipa.yml`.

1. Push this repository to a GitHub repository.
2. Open **Actions → Custom unsigned iOS IPA**.
3. Run the workflow manually.
4. Download the `openstrap-edge-custom-unsigned-ipa` artifact.
5. Sign/sideload it with your preferred iOS signing tool.

The workflow uses the same Flutter version as the project's release build and builds with `--no-codesign`.
